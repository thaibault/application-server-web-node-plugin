if(typeof window==='undefined'||window===null)var window=(typeof globalThis==='undefined'||globalThis===null)?{}:globalThis;import { Logger as __WEBPACK_EXTERNAL_MODULE_clientnode_Logger__, NOOP as __WEBPACK_EXTERNAL_MODULE_clientnode_NOOP__ } from "clientnode";
import { createServer as __WEBPACK_EXTERNAL_MODULE_http_createServer__ } from "http";
import { createSecureServer as __WEBPACK_EXTERNAL_MODULE_http2_createSecureServer__ } from "http2";

;// external "clientnode"

;// external "http"

;// external "http2"

;// ./index.ts
// #!/usr/bin/env babel-node
// -*- coding: utf-8 -*-
/** @module application-server-web-node-plugin *//* !
    region header
    [Project page](https://tsickert.com/application-server-web-node-plugin)

    Copyright Torben Sickert (info["~at~"]tsickert.com) 16.12.2012

    License
    -------

    This library written by Torben Sickert stands under a creative commons
    naming 3.0 unported license.
    See https://creativecommons.org/licenses/by/3.0/deed.de
    endregion
*/// region imports
function _typeof(o){"@babel/helpers - typeof";return _typeof="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(o){return typeof o}:function(o){return o&&"function"==typeof Symbol&&o.constructor===Symbol&&o!==Symbol.prototype?"symbol":typeof o},_typeof(o)}function _createForOfIteratorHelper(e,t){var _n="undefined"!=typeof Symbol&&e[Symbol.iterator]||e["@@iterator"];if(!_n){if(Array.isArray(e)||(_n=_unsupportedIterableToArray(e))||t&&e&&"number"==typeof e.length){_n&&(e=_n);var o=0,F=function F(){};return{s:F,n:function n(){return o>=e.length?{done:!0}:{done:!1,value:e[o++]}},e:function e(r){throw r},f:F}}throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")}var a,u,i=!0;return{s:function s(){_n=_n.call(e)},n:function n(){i=!0;var r=_n.next();return r.done?{done:!0}:{value:r.value,done:i=!1}},e:function e(r){a=!0,u=r},f:function f(){try{i||null==_n.return||_n.return()}finally{if(a)throw u}}}}function _toConsumableArray(a){return _arrayWithoutHoles(a)||_iterableToArray(a)||_unsupportedIterableToArray(a)||_nonIterableSpread()}function _nonIterableSpread(){throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")}function _unsupportedIterableToArray(t,e){if(t){if("string"==typeof t)return _arrayLikeToArray(t,e);var o={}.toString.call(t).slice(8,-1);return"Object"===o&&t.constructor&&(o=t.constructor.name),"Map"===o||"Set"===o?Array.from(t):"Arguments"===o||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(o)?_arrayLikeToArray(t,e):void 0}}function _iterableToArray(r){var e="undefined"!=typeof Symbol&&r[Symbol.iterator]||r["@@iterator"];if(Array.isArray(r)&&(null==e||e===("undefined"!=typeof Symbol&&[][Symbol.iterator])||e===[]["@@iterator"]))return r;if(null!=e){for(var t,o=[],a=e.call(r);!(t=a.next()).done;)o.push(t.value);return o}}function _arrayWithoutHoles(a){if(Array.isArray(a))return _arrayLikeToArray(a)}function _arrayLikeToArray(r,a){(null==a||a>r.length)&&(a=r.length);for(var e=0,n=Array(a);e<a;e++)n[e]=r[e];return n}function ownKeys(e,r){var t=Object.keys(e);if(Object.getOwnPropertySymbols){var o=Object.getOwnPropertySymbols(e);r&&(o=o.filter(function(r){return Object.getOwnPropertyDescriptor(e,r).enumerable})),t.push.apply(t,o)}return t}function _objectSpread(r){for(var t=1;t<arguments.length;t++){var o=null!=arguments[t]?arguments[t]:{};t%2?ownKeys(Object(o),!0).forEach(function(t){_defineProperty(r,t,o[t])}):Object.getOwnPropertyDescriptors?Object.defineProperties(r,Object.getOwnPropertyDescriptors(o)):ownKeys(Object(o)).forEach(function(e){Object.defineProperty(r,e,Object.getOwnPropertyDescriptor(o,e))})}return r}function _defineProperty(r,t,o){return(t=_toPropertyKey(t))in r?Object.defineProperty(r,t,{value:o,enumerable:!0,configurable:!0,writable:!0}):r[t]=o,r}function _toPropertyKey(r){var o=_toPrimitive(r,"string");return"symbol"==_typeof(o)?o:o+""}function _toPrimitive(t,e){if("object"!=_typeof(t)||!t)return t;var r;if("undefined"!=typeof Symbol&&void 0!==(r=t[Symbol.toPrimitive])){var i=r.call(t,e||"default");if("object"!=_typeof(i))return i;throw new TypeError("@@toPrimitive must return a primitive value.")}return("string"===e?String:Number)(t)};// NOTE: http2 compatibility mode does work for unencrypted connections yet.
// endregion
var log=new __WEBPACK_EXTERNAL_MODULE_clientnode_Logger__({name:"web-node.application-server"});// region plugins/classes
/**
 * Launches an application server und triggers all some pluggable hooks on an
 * event.
 *//**
 * Appends an application server to the web node services.
 * @param state - Application state.
 * @returns Promise resolving to nothing.
 */var preLoadService=function preLoadService(state){var configuration=state.configuration.applicationServer,pluginAPI=state.pluginAPI,services=state.services;var onIncomingMessage=function onIncomingMessage(request,response){void pluginAPI.callStack(_objectSpread(_objectSpread({},state),{},{data:{response:response,request:request},hook:"applicationServerRequest"})).then(function(){return response.end()})};var server={instance:configuration.nodeServerOptions.cert&&configuration.nodeServerOptions.key?__WEBPACK_EXTERNAL_MODULE_http2_createSecureServer__(configuration.nodeServerOptions,onIncomingMessage):// NOTE: See import notice.
__WEBPACK_EXTERNAL_MODULE_http_createServer__(onIncomingMessage),streams:[],sockets:[]};services.applicationServer=server;server.instance.on("connection",function(socket){server.sockets.push(socket);socket.on("close",function(){return server.sockets.splice(server.sockets.indexOf(socket),1)})});server.instance.on("stream",function(stream,headers){server.streams.push(stream);void pluginAPI.callStack(_objectSpread(_objectSpread({},state),{},{data:{headers:headers,stream:stream},hook:"applicationServerStream"}));stream.on("close",function(){return server.streams.splice(server.streams.indexOf(stream),1)})});return Promise.resolve()};/**
 * Start database's child process and return a Promise which observes this
 * service.
 * @param state - Application state.
 * @param state.configuration - Applications configuration.
 * @param state.configuration.applicationServer - Server configuration.
 * @param state.services - Application services.
 * @returns A mapping to promises which correspond to the plugin specific
 * continues services.
 */var loadService=function loadService(_ref){var configuration=_ref.configuration.applicationServer,services=_ref.services;if(Object.prototype.hasOwnProperty.call(services,"applicationServer"))return new Promise(function(resolve,reject){var parameters=[];if(configuration.hostName)parameters.push(configuration.hostName);parameters.push(function(){void log.info("Starting application server to listen on port","\"".concat(String(configuration.port),"\"."));resolve({applicationServer:new Promise(__WEBPACK_EXTERNAL_MODULE_clientnode_NOOP__)})});try{var _services$application;(_services$application=services.applicationServer.instance).listen.apply(_services$application,[configuration.port].concat(_toConsumableArray(parameters)))}catch(error){// eslint-disable-next-line prefer-promise-reject-errors
reject(error)}});return Promise.resolve(null)};/**
 * Application will be closed soon.
 * @param state - Application state.
 * @param state.services - Application services.
 * @returns Promise resolving to nothing.
 */var shouldExit=function shouldExit(_ref2){var services=_ref2.services;var server=services.applicationServer;return new Promise(function(resolve){server.instance.close(function(){delete services.applicationServer;resolve()});for(var _i=0,_arr=[server.sockets,server.streams];_i<_arr.length;_i++){var connections=_arr[_i];if(Array.isArray(connections)){var _iterator=_createForOfIteratorHelper(connections),_step;try{for(_iterator.s();!(_step=_iterator.n()).done;){var connection=_step.value;connection.destroy()}}catch(err){_iterator.e(err)}finally{_iterator.f()}}}})};// endregion
var applicationServer={preLoadService:preLoadService,loadService:loadService,shouldExit:shouldExit};/* harmony default export */ const index = (applicationServer);
export { applicationServer, index as default, loadService, log, preLoadService, shouldExit };
