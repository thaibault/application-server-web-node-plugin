import { PluginHandler, PluginPromises } from 'web-node/type';
import { ServicePromisesState, ServicesState } from './type';
/**
 * Launches an application server und triggers all some pluginable hooks on an
 * event.
 */
export declare class ApplicationServer implements PluginHandler {
    /**
     * Appends an application server to the web node services.
     * @param state - Application state.
     *
     * @returns Promise resolving to nothing.
     */
    static preLoadService(state: ServicesState): Promise<void>;
    /**
     * Start database's child process and return a Promise which observes this
     * service.
     * @param state - Application state.
     * @param state.configuration - Applications configuration.
     * @param state.configuration.applicationServer - Server configuration.
     * @param state.services - Application services.
     *
     * @returns A mapping to promises which correspond to the plugin specific
     * continues services.
     */
    static loadService({ configuration: { applicationServer: configuration }, services }: ServicePromisesState): Promise<null | PluginPromises>;
    /**
     * Application will be closed soon.
     * @param state - Application state.
     * @param state.services - Application services.
     *
     * @returns Promise resolving to nothing.
     */
    static shouldExit({ services }: ServicePromisesState): Promise<void>;
}
export default ApplicationServer;
