import { PluginAPI } from 'web-node';
import { Plugin, PluginHandler } from 'web-node/type';
import { Configuration, Service, ServicePromises, Services } from './type';
/**
 * Launches an application server und triggers all some pluginable hooks on an
 * event.
 */
export declare class ApplicationServer implements PluginHandler {
    /**
     * Start database's child process and return a Promise which observes this
     * service.
     * @param servicePromises - An object with stored service promise
     * instances.
     * @param services - An object with stored service instances.
     * @param configuration - Mutable by plugins extended configuration object.
     *
     * @returns A promise which correspond to the plugin specific continues
     * service.
     */
    static loadService(servicePromises: ServicePromises, services: Services, configuration: Configuration): Promise<null | Service>;
    /**
     * Appends an application server to the web node services.
     * @param services - An object with stored service instances.
     * @param configuration - Mutable by plugins extended configuration object.
     * @param plugins - Topological sorted list of plugins.
     * @param pluginAPI - Plugin api reference.
     *
     * @returns Given and extended object of services.
     */
    static preLoadService(services: Services, configuration: Configuration, plugins: Array<Plugin>, pluginAPI: typeof PluginAPI): Promise<Services>;
    /**
     * Application will be closed soon.
     * @param services - An object with stored service instances.
     *
     * @returns Given object of services.
     */
    static shouldExit(services: Services): Promise<Services>;
}
export default ApplicationServer;
